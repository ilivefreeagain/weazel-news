Config = Config or {}

Config.UseFivemerr = false