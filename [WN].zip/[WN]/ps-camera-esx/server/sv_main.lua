local ESX = nil

Citizen.CreateThread(function()
    ESX = exports['es_extended']:getSharedObject()  -- Correct way to get the ESX object
    while ESX == nil do
        Citizen.Wait(100)  -- Shorter wait to check for ESX object
    end
end)

-- Add Discord webhook here.
local webhook = ""

RegisterNetEvent("ps-camera:cheatDetect", function()
    local _source = source
    DropPlayer(_source, "Cheater Detected")
end)

RegisterNetEvent("ps-camera:requestWebhook", function(Key)
    local _source = source
    local event = ("ps-camera:grabbed%s"):format(Key)
    TriggerClientEvent(event, _source, webhook)
end)

RegisterNetEvent("ps-camera:CreatePhoto", function(url, streetName)
    local _source = source
    local player = ESX.GetPlayerFromId(_source)
    if not player then return end

    local info = {
        metaimage = url,
        metalocation = streetName,
        type = streetName,
        description = " Taken on " .. os.date("%Y-%m-%d") .. '  \n  Time - ' .. os.date("%I : %M")
    }
    exports.ox_inventory:AddItem(_source, 'photo', 1, info)
end)

