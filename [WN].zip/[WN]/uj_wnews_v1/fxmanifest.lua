fx_version "bodacious"
game "gta5"

this_is_a_map "yes"

-- data_file('DLC_ITYP_REQUEST')('stream/arcade_props/arcade_props.ytyp')

-- client_script 'client.lua'

-- client_script 'stream/client.lua'



dependency '/assetpacks'